from django.contrib import admin

from .models import DJ_Profile

admin.site.register(DJ_Profile)
