from django.apps import AppConfig


class DjProfileConfig(AppConfig):
    name = 'DJ_Profile'
